The NeistAir Mod, originally made by neistridlar,
(Original Forum Thread: https://forum.kerbalspaceprogram.com/index.php?/topic/174152-wip-neist-airliner-parts/ )
(original NeistAir Github Repository: https://github.com/neistridlar/Neist-Airliner-Parts/ )
(neistridlar on the KSP forums: https://forum.kerbalspaceprogram.com/index.php?/profile/20296-neistridlar/ )
now REUPDATED by KerbMario ( https://forum.kerbalspaceprogram.com/index.php?/profile/221047-kerbmario/ )



Since i started working on this, i had been adding Tweakscale support and Engine Ignitor Support for now.
(and more features/parts, see changelog or see in-game :P)



Sneak-Peek for P10:

Currently undecided. Probably CommunityTechTree (CTT) support. Kerbalism Failures are also in consideration.



Roadmap (I will be working top to bottom!)

Light Support for cabins (DONE)
CommunityTechTree Support (WIP)
ConnectedLivingSpace support
EngineLighting Support (DONE)


Changelog
P9.2 - 29th of may 2024
- minor TweakScale fix, thanks JonnyOThan

P9 - 19th of June 2022 (KerbMario)

- Proper Lighting Support for all Cabins 
- Put some Tweakscale MODULES into MMPatches
- added PartList.txt, for CommunityTechTree support in the future
- added a new Variant of the CF6 engine, which is lighter and therefore more efficient(Titanium and Composite Blades)
- various other stuff

P8 - 5th of June 2022 (KerbMario)
- added SimpleFuelSwitch Support for all Fuel Tanks
- added FilterExtensions as bundled (for now, i will hopefully find a workaround that doesn't need FilterExtensions bundled :P)
- added FilterExtensions Support
- fixed some Parts and their Tweakscale configs
- renamed 31-37AD to 37-50AD, as it was named wrongfully 
- added a custom animation to 25PC, i thought it was better (also i now know how animation works in Blender :D)

P7 - 3rd of June 2022 (KerbMario)
- added Tweakscale support for all parts
- fixed most part names.
- made some part descriptions better.
- Added EngineIgnitor Support to the 2 Engines.


P6 - 9th of September 2020 (neistridlar)
- Fixed flipped nodes on TCS parts


P5 - 29th of March 2020 (neistridlar)
- B73 cockpit added
- 12NCS-B73 added
- CS22 cockpit added
- 12NCS-CS22 added
- A38 cockpit added
- 18NCS-A38 added
- 50PC added
- 37-50AD Added
- Adapters now have proper textures
- Some IVAs have been populated with props.
- Possibly other stuff

P4 - 29th of August 2018 (neistridlar)
- Added more cargo bays
- Added more doors
- Added CF6 sounds by Eskandre
- Improved some textures

P3 - 13th of August 2018 (neistridlar)
- Added CF6 Engine
- Added a CF6 version without variants for Backwards compability

P2 - 30th of July 2018 (neistridlar)
- Now requiring KSP 1.4.x for Nosecones and TCS Tail pieces.

P1 - 29th of May 2018 (neistridlar)
-First Prerelease
-Made for Testing the modular wings.