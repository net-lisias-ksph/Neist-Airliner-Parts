The NeistAir Mod, originally made by neistridlar,
(Original Forum Thread: https://forum.kerbalspaceprogram.com/index.php?/topic/174152-wip-neist-airliner-parts/ )
(original NeistAir Github Repository: https://github.com/neistridlar/Neist-Airliner-Parts/ )
(neistridlar on the KSP forums: https://forum.kerbalspaceprogram.com/index.php?/profile/20296-neistridlar/ )


this time REUPDATED by KerbMario ( https://forum.kerbalspaceprogram.com/index.php?/profile/221047-kerbmario/ )



Since i started working on this, i had been adding Tweakscale support and Engine Ignitor SUpport for now.
i will be keeping updating it more.






Changelog



P7 - 3rd of June 2022 (KerbMario)
- added Tweakscale support for all parts
- fixed most part names.
- made some part descriptions better.
- Added EngineIgnitor Support to the 2 Engines.


P6 - 9th of September 2020 (neistridlar)
- Fixed flipped nodes on TCS parts


P5 - 29th of March 2020 (neistridlar)
- B73 cockpit added
- 12NCS-B73 added
- CS22 cockpit added
- 12NCS-CS22 added
- A38 cockpit added
- 18NCS-A38 added
- 50PC added
- 37-50AD Added
- Adapters now have proper textures
- Some IVAs have been populated with props.
- Possibly other stuff

P4 - 29th of August 2018 (neistridlar)
- Added more cargo bays
- Added more doors
- Added CF6 sounds by Eskandre
- Improved some textures

P3 - 13th of August 2018 (neistridlar)
- Added CF6 Engine
- Added a CF6 version without variants for Backwards compability

P2 - 30th of July 2018 (neistridlar)
- Now requiring KSP 1.4.x for Nosecones and TCS Tail pieces.

P1 - 29th of May 2018 (neistridlar)
-First Prerelease
-Made for Testing the modular wings.